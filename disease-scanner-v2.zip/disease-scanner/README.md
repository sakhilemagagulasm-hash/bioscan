# BioScan — Disease Detection PWA
## Complete Deployment Guide (Free, 1 Day)

---

## What You Have
- `index.html`     → The scanner app (camera + upload + CNN)
- `dashboard.html` → Website/dashboard people visit to download/use the app
- `manifest.json`  → Makes it installable as a PWA (like APK)
- `sw.js`          → Service worker for offline use
- `icons/`         → App icons

---

## Step 1: Set Up GitHub (10 minutes)

1. Go to https://github.com → Sign up (free)
2. Click **"New repository"**
3. Name it: `bioscan` (or any name)
4. Set to **Public**
5. Click **"Create repository"**

---

## Step 2: Upload Files (5 minutes)

**Option A — Via GitHub website (easiest on laptop):**
1. Inside your new repo, click **"uploading an existing file"**
2. Drag ALL files from this folder into the browser
3. Make sure to upload the `icons/` folder contents too
4. Click **"Commit changes"**

**Option B — Via Git (if installed):**
```bash
git init
git add .
git commit -m "Initial BioScan deploy"
git remote add origin https://github.com/YOUR_USERNAME/bioscan.git
git push -u origin main
```

---

## Step 3: Enable GitHub Pages (2 minutes)

1. Go to your repo → **Settings** tab
2. Scroll to **"Pages"** in the left sidebar
3. Under "Branch", select **main** → **/ (root)**
4. Click **Save**
5. Wait 2-3 minutes → your URL will be:
   **`https://YOUR_USERNAME.github.io/bioscan/`**

✅ That's your free hosting, forever.

---

## Step 4: Update Your Dashboard Link

In `dashboard.html`, replace:
```
https://YOUR-USERNAME.github.io/bioscan/
```
With your actual GitHub Pages URL, then re-upload.

---

## Step 5: Share the App

**Dashboard URL** (your main website):
```
https://YOUR_USERNAME.github.io/bioscan/dashboard.html
```

**Direct app URL** (for QR codes / sharing):
```
https://YOUR_USERNAME.github.io/bioscan/
```

**Embed in existing website:**
```html
<iframe
  src="https://YOUR_USERNAME.github.io/bioscan/"
  width="400" height="700" frameborder="0"
  allow="camera"
  style="border-radius:24px;"
></iframe>
```

---

## Step 6: Install on Phone (The "APK" Part)

**Android:**
1. Open `https://YOUR_USERNAME.github.io/bioscan/` in Chrome
2. Tap ⋮ (3 dots) → "Add to Home screen"
3. Done! It's on your home screen like a real app

**iPhone:**
1. Open in Safari
2. Tap Share button → "Add to Home Screen"

---

## Using a Custom CNN Model (Optional)

The app ships with 3 free models. To add your own:
1. Go to https://teachablemachine.withgoogle.com
2. Create "Image Project"
3. Upload images of diseases (healthy vs sick)
4. Train model → **Export** → "Upload"
5. Copy the URL → paste in BioScan app → Info tab → Custom Model

---

## Hosting Alternatives (All Free)

| Service | URL | Best For |
|---------|-----|----------|
| GitHub Pages | github.io | Static sites, this app |
| Netlify | netlify.app | Drag & drop deploy |
| Vercel | vercel.app | Fast CDN |
| Cloudflare Pages | pages.dev | Global edge |

All support PWAs and HTTPS (required for camera access).

---

## FAQ

**Q: Why PWA instead of real APK?**
A: A real APK needs Android Studio, Java, signing keys, and 2-7 days. A PWA installs in 10 seconds and works identically on the home screen.

**Q: Does it work offline?**
A: Yes — after first load, the app works without internet.

**Q: Is my data private?**
A: Yes — all AI runs on your device. No images are uploaded anywhere.

**Q: Can I change the disease categories?**
A: Yes — use Teachable Machine to train on your specific diseases, then paste the URL in the app.

---

## Support
- TensorFlow.js: https://www.tensorflow.org/js
- Teachable Machine: https://teachablemachine.withgoogle.com
- GitHub Pages: https://pages.github.com
